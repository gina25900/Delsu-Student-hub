DELSU STUDENT HUB

Files:
- index.html: the website content and sections
- styles.css: responsive styling
- script.js: mobile navigation, current year and contact form email handoff

How to preview:
1. Extract the ZIP file.
2. Open the folder in your code editor (VS Code, Acode, etc.).
3. Open index.html in a browser.

How to publish:
- Upload the extracted folder to Netlify, or connect it to a GitHub repository.
- This is a static front-end website. The contact form opens the visitor's email app; it does not save messages to a database.
- Replace or expand the sample sections as you collect verified student information.

Community links included:
WhatsApp: https://chat.whatsapp.com/CcCsDD2YUZI5JhGtnhDmTV?s=cl&p=a&mlu=4&ilr=4&iam=2
Telegram: https://t.me/+EH5wyHEUiYQ5YjU0
WhatsApp contact: https://wa.me/2347082575155
Email: kevufavour@gmail.com

The website clearly identifies itself as an independent community project, not an official DELSU website.
